var usuario = 0;
var b1 = 0;
var b2 = 0;
var b5 = 0;
var b10 = 0;
var b20 = 0;
var b50 = 0;
var total = 950000; 
var Nom1 = "";
var Nom2 = "";
var Nom3 = "";
var Cuenta1 = 0;
var Cuenta2 = 0;
var Cuenta3 = 0;
var Clave1 = "";
var Clave2 = "";
var Clave3 = "";
var Monto1 = 0;
var Monto2 = 0;
var Monto3 = 0;
var cuentaRet = "";
var claveRet = "";
var montoRet ="";
var cuentaDep = "";
var montoDep = "";

function CrearUsuario() {    
    if (Cuenta1 == 0) {     //cuando la cuenta1 este vacia (=0) se va a llenar esta 
        Nom1 = document.getElementById(nombre).value; 
        Cuenta1 = parseInt(document.getElementById(cuenta).value);
        Clave1 = document.getElementById(clave).value; 
     } else if (Cuenta2 == 0){    // si la cuenta1 ya tiene datos, se llena la cuenta2
            Nom2 = document.getElementById(nombre).value; 
            Cuenta2 = parseInt(document.getElementById(cuenta).value);
            Clave2 = document.getElementById(clave).value;  
        } else if (Cuenta3 == 0) {
                Nom3 = document.getElementById(nombre).value; 
                Cuenta3 = parseInt(document.getElementById(cuenta).value);
                Clave3 = document.getElementById(clave).value; 
        
        }
}

function agregarUsuario(){
    
    var x= document.getElementById("nomUsuario").value;  // se declaran los valores que se van a obtener de los campos 
    var y= document.getElementById("numCuenta").value;
    var z= document.getElementById("clave").value;
    var a= document.getElementById("montoUsuario").value;

if (x!="" && y!="" && z!="" && a!=""){
    if (isNaN(y)==false && isNaN(a)==false) {     //valida si solo hay numeros
        
        if (usuario==0){  //si el primer campo para usuario esta vacio, anota el primer usuario aqui
                Nom1 = x;
                Cuenta1 = parseInt(y);  //siempre que sea numeros "parseInt"
                Clave1 = z;
                Monto1 = parseInt(a); 
            document.getElementById("nomUsuario").value= null; 
            document.getElementById("numCuenta").value= null; 
            document.getElementById("clave").value= null; 
            document.getElementById("montoUsuario").value= null; 
            usuario++;
                Materialize.toast("Se inserto correctamente", 3000);  //mensaje

            
        } else if (usuario==1) {  //cuando el primer usuario se ha guardado, guarda el 2do aqui
                Nom2 = x;
                Cuenta2 = parseInt(y);  //siempre que sea numeros "parseInt"
                Clave2 = z;
                Monto2 = parseInt(a); 
            document.getElementById("nomUsuario").value= null; 
            document.getElementById("numCuenta").value= null; 
            document.getElementById("clave").value= null; 
            document.getElementById("montoUsuario").value= null; 
            usuario++;
          Materialize.toast("Se inserto correctamente", 3000);  //mensaje

        } else if (usuario==2) {  //cuando el segundo se lleno, el 3ro aqui
                Nom3 = x;
                Cuenta3 = parseInt(y);  //siempre que sea numeros "parseInt"
                Clave3 = z;
                Monto3 = parseInt(a); 
            document.getElementById("nomUsuario").value= null; 
            document.getElementById("numCuenta").value= null; 
            document.getElementById("clave").value= null; 
            document.getElementById("montoUsuario").value= null;  
            usuario++;
         Materialize.toast("Se inserto correctamente", 3000);  //mensaje

        } else {
                 Materialize.toast("Ya no se pueden insertar más usuarios", 3000);  //mensaje de error
        }
        
    } else {
                Materialize.toast("Solo números en Cuenta y Monto", 3000);  //mensaje de error
    }
    
    } else {
        Materialize.toast("Faltan datos", 3000);   //mensaje de error
              
        } 
consultaUsuario();
}

function llenarCajero() {
    b1 = 30;
    b2 = 50;
    b5 = 20;
    b10 = 20;
    b20 = 15;
    b50 = 5;
 
    consultaCajero();
 Materialize.toast("El cajero se ha llenado correctamente", 3000);  //mensaje de error
}

consultaCajero();
function consultaCajero() {
        document.getElementById("bmil").innerHTML= b1;
        document.getElementById("bdos").innerHTML= b2;
        document.getElementById("bcinco").innerHTML= b5;
        document.getElementById("bdiez").innerHTML= b10;
        document.getElementById("bveinte").innerHTML= b20;
        document.getElementById("bcincuenta").innerHTML= b50;

}

consultaUsuario();
function consultaUsuario() {
    
     document.getElementById("Nom1").innerHTML = Nom1;
    document.getElementById("Cuenta1").innerHTML = Cuenta1;
    document.getElementById("Monto1").innerHTML = Monto1;
         
    document.getElementById("Nom2").innerHTML = Nom2;
    document.getElementById("Cuenta2").innerHTML = Cuenta2;
    document.getElementById("Monto2").innerHTML = Monto2;
         
    document.getElementById("Nom3").innerHTML = Nom3;
    document.getElementById("Cuenta3").innerHTML = Cuenta3;
    document.getElementById("Monto3").innerHTML = Monto3;
}


function Depositos() {
    document.getElementById("cuentaDep").value = cuentaDep;
    document.getElementById("montoDep").value = montoDep;
    
    if (cuentaDep = Cuenta1) {
        Monto1= Monto1 + montoDep;
        total = toatl + montoDep;
        
         Materialize.toast("Deposito correcto", 3000);  //mensaje 
        
    } else if (cuentaDep = Cuenta2) {
        Monto2= Monto2 + montoDep;
        total= total+ montoDep;
        Materialize.toast("Deposito correcto", 3000);  //mensaje
        
    } else if (cuentaDep = Cuenta3) {
        Monto3= Monto3 + montoDep;
        total = total + montoDep;
        Materialize.toast("Deposito correcto", 3000);  //mensaje de error

    }
    
}

        













